#include "Cliente.hpp"

using namespace std;

void Cliente::SetTelefone(string Telefone) {
    this->Email = Email;
}

string Cliente::GetTelefone() {
    return this->Telefone;
}